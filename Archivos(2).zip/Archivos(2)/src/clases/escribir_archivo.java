/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.FileWriter;
import java.io.PrintWriter;

/**
 *
 * @author alumno
 */
public class escribir_archivo {
    public void escribir_archivo(){
        FileWriter archivo = null;
        PrintWriter printWriter;
        
        try {
            String userDir = System.getProperty("user.home");
            String fileDir = "\\Desktop\\Prueba.txt";
            archivo = new FileWriter(userDir+fileDir);
            System.out.println("Escribiendo al directorio\n"+userDir+fileDir);
            printWriter = new PrintWriter (archivo);
            for (int i=0; i<10; i++){
                printWriter.println("Linea "+i);
            }
        }catch(Exception Err){
            System.out.print(Err);
        }finally {
            try{
                if (null !=archivo){
                    
                }
            }catch(Exception Err){
                System.err.println(Err);
            }
        }
    }
}
