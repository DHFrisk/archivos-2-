/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.File;

/**
 *
 * @author alumno
 */
public class espacio_disco {
    public void espacio_disco(){
     File[] roots= File.listRoots();
     for(File root : roots){
         System.out.println("En "+root+"Hay "+root.getFreeSpace());
     }
    }
}
