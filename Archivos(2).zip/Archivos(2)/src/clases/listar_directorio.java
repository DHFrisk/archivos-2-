/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.File;

/**
 *
 * @author alumno
 */
public class listar_directorio {
     public void lista_directorio(){
        try {
            File directorio = new File("C:\\");
            if (directorio.isDirectory()){
                File[] ficheros = directorio.listFiles();
                for (File fichero : ficheros){
                    System.out.println(fichero.getName());
                   
                }
            }
        }catch (Exception Err){
            System.out.print(Err);
        }
    }
}
