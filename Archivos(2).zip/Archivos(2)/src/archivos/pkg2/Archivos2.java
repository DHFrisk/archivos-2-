/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos.pkg2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import clases.espacio_disco;

/**
 *
 * @author alumno
 */
public class Archivos2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
            BufferedReader read= new BufferedReader(new InputStreamReader(System.in));
            String seleccion;
            System.out.println("1. -Espacio libre en disco: \n" + "2. -Mostrar Lista" + "\n 3.-Temporal"4 + "\n 4.-Desktop");
            seleccion = read.readLine();
            
            switch(seleccion){
                case "1":{
                    clases.espacio_disco espacio_disco = new clases.espacio_disco();
                    espacio_disco.espacio_disco(); 
                
                }break;
                
                case "2":{
                    clases.listar_directorio listar_directorio = new clases.listar_directorio();
                    listar_directorio.lista_directorio();
                
                }break;
                
                case "3":{
                    clases.TempFiles temp_files = new clases.TempFiles();
                    temp_files.TempFiles();
                
                }break;
                default: {System.err.println("Error de seleccion" + seleccion);}break;
                
                
            }
                    
            
            
        } catch(IOException ioErr){
            System.out.println(ioErr);
        }
        // TODO code application logic here
    }
    
}
